#include<iostream>
#include<iomanip>
#include<string>

using namespace std;
int main() {
	string name ;

	cout<<"Enter your name: ";
	getline(cin , name);
	cout<< "Howdy: ";
	cout<< setw(7) <<	setfill('*') << name<<"\n";
	
	cout<<"Enter your name: ";
	getline(cin , name);
	cout<< "Howdy: ";
	cout<< setw(7)<< setfill('*') << name <<"\n";
	
	cout<<"Enter your name: ";
	getline(cin , name);
	cout<< "Howdy: ";
	cout<< setw(7) << setfill('*') << name <<"\n";
	
	return 0;
}
