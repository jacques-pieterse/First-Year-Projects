#include <iostream>
#include <stdlib.h>

using namespace std;
int main() {
	int snumber, i;
	i = 0;
	
	srand(14);
	
	while (i < 2) {
		cout << "Enter your student number: ";
		cin >> snumber;
		i += 1;
		
		if (snumber % 2 == 0) {
			cout << (rand() % (99 - 10 + 1)) + 10 << " is ready to take on COS 132!\n";
		}
		
		else if (snumber % 2 != 0) {
			cout << snumber << " is really excited for COS 132!\n";
		}
	}
	return 0;
}
