#include<iostream>
#include<cmath>
#include<iomanip>

using namespace std;
int main() {
	double x, y;
	
	cout<<"Enter a value of x: ";
	cin>>x;
	
	y = ((cos(pow(x , 2.0))) / (5 + (2*cos(x))))+((sin(pow(x , 2.0))) / (5 * M_PI)) + ((tan(x)) / ((cos(x))+sin(x)));
	
	cout<<"The answer is: ";
	cout<<setprecision(5)<<fixed<<showpoint<<y<<endl;
	
	
	return 0;
}
